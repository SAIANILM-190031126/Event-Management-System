CREATE SCHEMA `Project`;
CREATE TABLE `Project`.`Login`(
 `Emailaddress` VARCHAR(60) NOT NULL,
 `Password` VARCHAR(60) NOT NULL);
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('abcd@gmail.com','buha123');
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('efgh@gmail.com','fedb123');
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('ijkl@gmail.com','gerga123');
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('mnop@gmail.com','ferhty123');
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('qrst@gmail.com','uyoij123');
 INSERT INTO `Project`.`Login`(`Emailaddress`,`Password`) VALUES('uvwx@gmail.com','rtgiug123');
 SELECT * FROM  Login;
 
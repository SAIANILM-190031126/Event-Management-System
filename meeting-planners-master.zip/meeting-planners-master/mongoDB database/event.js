db.event.insert(
 [
   {
     eventname:"Marriage",
     budget:"2500000",
     numberofpeople:200,
     venue:"SVS kalyanamandapam,Hyderabad"
   },

   {
     eventname:"Birthday",
     budget:"100000",
     numberofpeople:50,
     venue:"Grand convention,Vizag"
   },

   {
     eventname:"Concert",
     budget:"1000000",
     numberofpeople:100,
     venue:"Fun convention,Vijayawada"
   },

   {
     eventname:"Meetings",
     budget:"500000",
     numberofpeople:100,
     venue:"TTD kalyanamandapam,kakinada"
   }
  ]
);
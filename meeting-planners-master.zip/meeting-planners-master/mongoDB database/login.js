db.login.insert(
 [
   {
     username:"Gayathri@789",
     password:"okavhr2",
     email:"Gayathri@gmail.com"
   },

   {
     username:"Suma@920",
     password:"pfhjnbu",
     email:"Suma1997@gmail.com"
   },

   {
     username:"Ikbal7521",
     password:"yuefbii",
     email:"Ikbal753@gmail.com"
   },

   {
     username:"Veer75412",
     password:"pjhgccqs",
     email:"Veeranshu456@gmail.com"
   }

 ]
);
   

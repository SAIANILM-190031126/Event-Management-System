CREATE TABLE `Project`.`Venue`(
 `Venue id` INT NOT NULL,
 `Venue name` VARCHAR(45) NOT NULL,
 `Venue city` VARCHAR(40) NOT NULL,
 `Venue landmark` VARCHAR(40) NOT NULL,
 `Venue state` VARCHAR(60) NOT NULL,
 PRIMARY KEY(`Venue id`));
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1000', 'Gadiraju palace', 'Vishakapatnam','Dwaraka nagar','Andhra Pradesh');
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1001', 'Suvarna Kalyanavedika', 'Hyderabad','Rampally cross roads','Telangana');
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1002', 'TTD kalyanamandapam', 'Kakinada','Balaji cheruvu', 'Andhra Pradesh');
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1003', 'Srinivasa Kalyanamandapam', 'Rajamundry','Danavai peta', 'Andhra Pradesh');
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1004', 'Vysyaraju convention', 'Warangal','Farid peta','Telangana');
 INSERT INTO `Project`.`Venue` (`Venue id`, `Venue name`, `Venue city`,`Venue landmark`,`Venue state`) VALUES ('1005', 'Hotel Grand', 'Srikakulam','Ramalakshmana centre','Andhra Pradesh');
 SELECT * FROM Venue;
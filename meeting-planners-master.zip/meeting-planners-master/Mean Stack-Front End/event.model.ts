export class Event {
    _id: string;
    name: string;
    occasion: string;
    date_and_venue: string;
    budjet: number;
}

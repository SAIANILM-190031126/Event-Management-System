import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-blog',
  templateUrl: './app-blog.component.html',
  styleUrls: ['./app-blog.component.css']
})
export class AppBlogComponent implements OnInit {

  constructor() { }

  blogimg: any = '../../../assets/images/blog/blog.jpg';
 

  posts: any[] = [
    { title: 'post one', content: 'This is event one', by: 'jessi', on: '12/02/2020' },
    { title: 'post two', content: 'This is event Two', by: 'smith', on: '02/07/2020' },
    { title: 'post three', content: 'This is event Three', by: 'Will', on: '11/03/2019' }];

  ngOnInit() {
  }

}

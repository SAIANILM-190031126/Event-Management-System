CREATE TABLE `Project`.`Bill`(
 `Bill_no` INT NOT NULL,
 `Order_no` INT NOT NULL,
 `Email_addr` VARCHAR(45) NOT NULL,
 `Amount` BIGINT NOT NULL,
 `Tax` BIGINT NOT NULL,
 `Deliver_charge` BIGINT NOT NULL,
 `Final_amt` BIGINT NOT NULL,
 `Bill_date` DATE NOT NULL,
 PRIMARY KEY(`Bill_no`));
 INSERT INTO `Project`.`Bill`(`Bill_no`,`Order_no`,`Email_addr`,`Amount`,`Tax`,`Deliver_charge`,`Final_amt`,`Bill_date`) VALUES ('7000','6000','abcd@gmail.com','1900000','50000','50000','2000000','2020-10-29');
 INSERT INTO `Project`.`Bill`(`Bill_no`,`Order_no`,`Email_addr`,`Amount`,`Tax`,`Deliver_charge`,`Final_amt`,`Bill_date`) VALUES ('7001','6001','efgh@gmail.com','50000','12000','13000','75000','2020-10-20');
 INSERT INTO `Project`.`Bill`(`Bill_no`,`Order_no`,`Email_addr`,`Amount`,`Tax`,`Deliver_charge`,`Final_amt`,`Bill_date`) VALUES ('7002','6002','ijkl@gmail.com','200000','50000','50000','300000','2020-11-01');
 INSERT INTO `Project`.`Bill`(`Bill_no`,`Order_no`,`Email_addr`,`Amount`,`Tax`,`Deliver_charge`,`Final_amt`,`Bill_date`) VALUES ('7003','6003','mnop@gmail.com','400000','25000','75000','500000','2020-10-27');
SELECT * FROM Bill;
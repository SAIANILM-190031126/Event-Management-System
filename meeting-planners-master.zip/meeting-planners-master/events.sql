CREATE TABLE `Project`.`Events`(
 `Event_code` VARCHAR(20) NOT NULL,
 `Event type` VARCHAR(45) NOT NULL,
 `Event minimumbudget` BIGINT NOT NULL,
 PRIMARY KEY(`Event_code`));
 INSERT INTO `Project`.`Events` (`Event_code`, `Event type`, `Event minimumbudget`) VALUES ('E01', 'Marriage', '1000000');
 INSERT INTO `Project`.`Events` (`Event_code`, `Event type`, `Event minimumbudget`) VALUES ('E02', 'Birthday', '25000');
 INSERT INTO `Project`.`Events` (`Event_code`, `Event type`, `Event minimumbudget`) VALUES ('E03', 'Farewell', '500000');
 INSERT INTO `Project`.`Events` (`Event_code`, `Event type`, `Event minimumbudget`) VALUES ('E04', 'Concert', '300000');
 INSERT INTO `Project`.`Events` (`Event_code`, `Event type`, `Event minimumbudget`) VALUES ('E05','Meeting', '200000');
 SELECT * FROM  Events;
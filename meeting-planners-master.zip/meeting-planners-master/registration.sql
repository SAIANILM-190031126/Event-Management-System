CREATE TABLE `Project`.`Registration`(
 `User_id` VARCHAR(60) NOT NULL,
 `Password` VARCHAR(60) NOT NULL,
 `Repeat_password` VARCHAR(60) NOT NULL,
 `First name` VARCHAR(60) NOT NULL,
 `Last name` VARCHAR(60) NOT NULL,
 `DOB` date NOT NULL, 
 `City` VARCHAR(40) NOT NULL,
 `State` VARCHAR(40) NOT NULL,
 `Phone_number` BIGINT NOT NULL,
 `Email_id` VARCHAR(60) NOT NULL,
 PRIMARY KEY(`User_id`));
 INSERT INTO `Project`.`Registration` (`User_id`,`Password`,`Repeat_password`,`First name`,`Last name`,`DOB`,`City`,`State`,`Phone_number`,`Email_id`) VALUES('Ravi_G','rgth123','rgth123','Ravi','Gorle','1990-02-15','Hyderabad','Telangana','7534569512','bewh@gmail.com');
 INSERT INTO `Project`.`Registration` (`User_id`,`Password`,`Repeat_password`,`First name`,`Last name`,`DOB`,`City`,`State`,`Phone_number`,`Email_id`) VALUES('Avika_S','okjuh852','okjuh852','Avika','Seepana','1986-01-25','Vijayawada','Andhra Pradesh','7651559975','olkj@gmail.com');
 INSERT INTO `Project`.`Registration` (`User_id`,`Password`,`Repeat_password`,`First name`,`Last name`,`DOB`,`City`,`State`,`Phone_number`,`Email_id`) VALUES('Deeraj_I','ewggh753','ewggh753','Dheeraj','Inukula','1996-08-16','Rajamundry','Andhra Pradesh','4821559622','uknjb@gmail.com');
 INSERT INTO `Project`.`Registration` (`User_id`,`Password`,`Repeat_password`,`First name`,`Last name`,`DOB`,`City`,`State`,`Phone_number`,`Email_id`) VALUES('Vidhya_T','wdfg951','wdfg951','Vidhya','Tirula','1994-02-06','Warangal','Telangana','8527419637','ewqghd@gmail.com');
 SELECT * FROM Registration
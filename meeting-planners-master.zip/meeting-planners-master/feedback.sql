CREATE TABLE `Project`.`Feedback`(
  `Email_id` VARCHAR(60) NOT NULL,
  `Subject` VARCHAR(60) NOT NULL,
  `Message` VARCHAR(100) NOT NULL);
  INSERT INTO `Project`.`Feedback`(`Email_id`,`Subject`,`Message`) VALUES('abcd@gmail.com','NICE','Satisfied with the service');
  INSERT INTO `Project`.`Feedback`(`Email_id`,`Subject`,`Message`) VALUES('efgh@gmail.com','GOOD','Saved my time!');
  INSERT INTO `Project`.`Feedback`(`Email_id`,`Subject`,`Message`) VALUES('ijkl@gmail.com','SATISFIED','Good service');
  INSERT INTO `Project`.`Feedback`(`Email_id`,`Subject`,`Message`) VALUES('mnop@gmail.com','Feedback','Easy to use');
  SELECT * FROM Feedback;
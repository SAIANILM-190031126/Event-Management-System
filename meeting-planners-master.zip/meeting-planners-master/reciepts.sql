CREATE TABLE `Project`.`Receipts`(
 `Receipt_no` INT NOT NULL,
 `Bill_no` INT NOT NULL,
 `Tot_amt` BIGINT NOT NULL,
 `Paid_amt` BIGINT NOT NULL,
 `Balance` BIGINT NOT NULL,
 `Receipt_date` DATE NOT NULL,
 PRIMARY KEY(`Receipt_no`));
 INSERT INTO `Project`.`Receipts`(`Receipt_no`,`Bill_no`,`Tot_amt`,`Paid_amt`,`Balance`,`Receipt_date`) VALUES ( '8000','7000','2000000','1500000','500000','2020-10-29');
 INSERT INTO `Project`.`Receipts`(`Receipt_no`,`Bill_no`,`Tot_amt`,`Paid_amt`,`Balance`,`Receipt_date`) VALUES ( '8001','7001','75000','75000','0','2020-10-20');
 INSERT INTO `Project`.`Receipts`(`Receipt_no`,`Bill_no`,`Tot_amt`,`Paid_amt`,`Balance`,`Receipt_date`) VALUES ( '8002','7002','300000','200000','100000','2020-11-01');
 INSERT INTO `Project`.`Receipts`(`Receipt_no`,`Bill_no`,`Tot_amt`,`Paid_amt`,`Balance`,`Receipt_date`) VALUES ( '8003','7003','500000','300000','200000','2020-10-27');
 SELECT * FROM Receipts;